# PACE2025 Docker Guide

This guide explains how to build and run the inference for the **ultrasound multi-task segmentation and classification model** in a Docker environment with GPU support.

---

## 📌 Project Overview

This Docker container runs a multi-task deep learning model for ultrasound image analysis that can perform:

- **Segmentation** – Generates binary masks for ultrasound images  
- **Classification** – Classifies ultrasound images into predefined categories  
---

## 📂 Project Structure
```
├── Dockerfile
├── requirements.txt
├── main.py                 # Main inference script
├── model.py               # Model architecture
├── checkpoints/           # Model weights directory
│   └── best_model.pth    # Trained model checkpoint
└── tools/                # Preprocessing and postprocessing utilities
    ├── preprocess.py
    └── postprocess.py
```

## 1. Install Docker
First, install Docker Desktop (available for Windows, macOS, and Linux):

- Download: https://www.docker.com/get-started/

After installation, verify Docker is available:

```sh
docker --version
```
If it shows a version number, Docker is installed correctly.

## 2. Build the Docker Image
Assuming your project code and Dockerfile are in the same directory:

```sh
cd /path/to/docker
docker build -f Dockerfile -t [image_name] .
```

Parameters:
- `-f Dockerfile` — specify the Dockerfile to use.
- `-t [image_name]` — name the image, e.g., uusic.
- `.` — use the current directory as the build context.

Example:
```sh
docker build -f Dockerfile -t PACE2025 .
```

## 3. Run the Docker Container
### For Segmentation Task

To run the **segmentation task** using the Docker container with GPU support:

```sh
docker run --gpus all --rm \
  -v [/path/to/input/images]:/input:ro \
  -v [/path/to/output]:/output \
  -it [image_name] python main.py -i /input -o /output -t seg -d gpu
```
### For Classification Task

To run the **classification task** using the Docker container with GPU support:

```sh
docker run --gpus all --rm \
  -v [/path/to/input/images]:/input:ro \
  -v [/path/to/output]:/output \
  -it [image_name] python main.py -i /input -o /output -t cls -d gpu
```

## Docker Parameters

- `--gpus all` — enable all available GPUs inside the container  
- `--rm` — remove the container automatically after it stops  
- `-v /host/path:/container/path` — mount a local directory into the container:  
  - `/input:ro` — input image directory (read-only)  
  - `/output` — output results directory  
- `-it` — interactive mode  
- `[image_name]` — the Docker image name  

---

## Command-Line Arguments

- `-i, --input` — Path to input directory containing PNG ultrasound images  
- `-o, --output` — Path to output directory  
- `-t, --task` — Task to perform: `seg` for segmentation, `cls` for classification  
- `-d, --device` — Device to use: `cpu` or `gpu` (default: `gpu`)  

## Output Structure

### Segmentation Task Output
```
output_directory/
└── segmentation/
    ├── PACE_00001_000_BUS_mask.png
    ├── PACE_00002_001_BRE_mask.png
    └── ...
```

### Classification Task Output
```
output_directory/
└── classification/
    └── predictions.csv    # Contains image_id, label columns
```
#### predictions.csv
```
image_id,label
PACE_00001_000_BUS,Normal
PACE_00002_001_BRE,Benign
```
## Submit the Docker Image

The submission platform for the Docker container will be shared soon.

Build and test your image locally
