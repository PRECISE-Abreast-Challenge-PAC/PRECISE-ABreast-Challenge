
    
def preprocess_segmentation(image):
    """
    Preprocess image for segmentation task.
    
    """
    pass
    
def preprocess_classification(image):
    """
    Preprocess image for classification task.
    
    """
    pass
